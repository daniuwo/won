function toast(msg){
    return mdui.snackbar({
        message: msg,
    });
}