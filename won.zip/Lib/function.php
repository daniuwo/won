<?php
// +------------------------------------------------------
// | Description: 扩展函数
// | Author: 红着自己玩 <956716282@qq.com>
// | Date: 2019-08-29 19:15:25 
// | LastEditors: 红着自己玩 <956716282@qq.com>
// | LastEditTime: 2019-08-29 19:19:22 
// | Github: https://github.com/daniuwo/won.git
// | Copyright (c) 2019 http://won.cm All rights reserved.
// +------------------------------------------------------
function WN_URL($action, $method = '', $age = [], $ext = '') {
	echo WWW.(C('REWRITE') ? '' : '?') . URL($action, $method, $age, $ext);
}
function WN_URLA($action, $method = '', $age = [], $ext = '') {
	return WWW.(C('REWRITE') ? '' : '?') . URL($action, $method, $age, $ext);
}