   

    <!-- END: Footer-->
    <!-- BEGIN VENDOR JS-->
    <script src="{#WWW_STATIC}admin/app-assets/js/vendors.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN THEME  JS-->
    <script src="{#WWW_STATIC}admin/app-assets/js/plugins.js" type="text/javascript"></script>
    <script src="{#WWW_STATIC}admin/app-assets/js/custom-script.js" type="text/javascript"></script>
    <script src="{#WWW_STATIC}admin/app-assets/js/customizer.js" type="text/javascript"></script>
    <!-- END THEME  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- END PAGE LEVEL JS-->
  </body>
</html>