{include common/head}
<!-- BEGIN: Header-->
{include common/header}
<!-- END: Header-->


{include common/sidenav}
<!-- END: SideNav-->
<!-- BEGIN: Page Main-->
<div id="main">
    <div class="row">
        <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
        <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
            <!-- Search for small screen-->
            <div class="container">
                <div class="row">
                    <div class="col s10 m6 l6">
                        <h5 class="breadcrumbs-title mt-0 mb-0">{$title}</h5>
                        <ol class="breadcrumbs mb-0">
                            <li class="breadcrumb-item"><a href="index.html">首页</a>
                            </li>
                            <li class="breadcrumb-item active">{$title}
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="col s12">
            <div class="container">
                <div class="section">
                    <div class="card">
                        <div class="card-content">
                            <p>网站设置,配置网站基本信息</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col s12">
                            <div id="basic-form" class="card card card-default scrollspy">
                                <div class="card-content">
                                    <h4 class="card-title">参数设置</h4>
                                    <form class="col s12" action="" method="post">
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <input type="text" id="fn" name="wwwname" value="{$config_www.wwwname}">
                                                <label for="fn" class="">网站名称</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <input id="text" type="text" name="domain" value="{$config_www.domain}">
                                                <label for="text" class="">网站域名</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <input id="keywords" type="text" name="keywords" value="{$config_www.keywords}">
                                                <label for="keywords" class="">keywords</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <input id="description" type="text" name="description" value="{$config_www.description}">
                                                <label for="description" class="">description</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <input id="Email" type="text" name="email" value="{$config_www.email}">
                                                <label for="Email" class="">Email</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <input id="qq" type="text" name="qq" value="{$config_www.qq}">
                                                <label for="qq" class="">站长QQ</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <select name="weihu">
                                                    <option value="0" {if $config_www['weihu'] == 0}selected{/if}>开启网站</option>
                                                    <option value="1" {if $config_www['weihu'] == 1}selected{/if}>关闭网站</option>
                                                </select>
                                            </div>
                                            <div class="input-field col s12">
                                                <input id="weihu_msg" type="text" name="weihu_msg" value="{$config_www.weihu_msg}">
                                                <label for="weihu_msg" class="">网站维护描述(关闭网站后显示)</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <input id="banquan" type="text" name="banquan" value="{$config_www.banquan}">
                                                <label for="banquan" class="">版权代码</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <textarea id="tongji" name="tongji" class="materialize-textarea" rows="6" >{$config_www.tongji}</textarea>
                                                <label for="tongji" class="">网站统计代码</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <button class="btn cyan waves-effect waves-light" type="submit" name="action">保存
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END: Page Main-->
    {include common/footer}
    {include common/foot}