{include common/header}
<a href="{#URL('index','edit')}">编辑模式</a>
{include common/footer}