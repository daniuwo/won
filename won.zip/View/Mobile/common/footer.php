    <script src="{#WWW_STATIC}mobile/js/ydui.js"></script>
</body>
</html>