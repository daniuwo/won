<div class="mdui-toolbar mdui-color-theme">
    <a href="javascript:history.back(-1);" class="mdui-btn mdui-btn-icon"><i class="mdui-icon iconfont iconarrow-left-line"></i></a>
    <span class="mdui-typo-title">{$title}</span>
    <div class="mdui-toolbar-spacer"></div>
</div>