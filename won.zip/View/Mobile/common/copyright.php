<div style="text-align: center;padding: 10px 0 20px;">
    <div>
        Powered by <a href="#" style="color: #2dc5d8;">蜗牛系统</a> Version 1.0
    </div>
</div>