<footer class="m-tabbar">
    <a href="#" class="tabbar-item tabbar-active">
        <span class="tabbar-icon">
            <i class="icon-home"></i>
        </span>
        <span class="tabbar-txt">首页</span>
    </a>
    <a href="#" class="tabbar-item">
        <span class="tabbar-icon">
            <i class="icon-shopcart-outline"></i>
        </span>
        <span class="tabbar-txt">购物车</span>
    </a>
    <a href="#" class="tabbar-item">
        <span class="tabbar-icon">
            <i class="icon-ucenter-outline"></i>
        </span>
        <span class="tabbar-txt">个人中心</span>
    </a>
</footer>